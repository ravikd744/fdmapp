// App.js (Main Component)

import React, { useState } from 'react';
import './App.css'; // Bootstrap styles

// Components
import Header from './components/Header';
import MainPanelContainer from './components/MainPanelContainer';
import Home from './components/Home';
import Customer from './components/Customer';
import Footer from './components/Footer';

//contexts
import { SearchContext } from './components/Contexts.js';

const App = () => {
const [selectedPage, setSelectedPage] = useState('Home');
const contextValue = { selectedPage, setSelectedPage };
  return (
    <div className="App">
	 <SearchContext.Provider value={contextValue}>
        <Header/>
      <MainPanelContainer />
      <Footer />
      
    </SearchContext.Provider>
      
    </div>
  );
};

export default App;
