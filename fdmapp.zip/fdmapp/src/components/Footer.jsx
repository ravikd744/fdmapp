// components/Footer.js

import React from 'react';

const Footer = () => {
  return <footer class="bg-primary">© 2024 Federated Web App</footer>;
};

export default Footer;
