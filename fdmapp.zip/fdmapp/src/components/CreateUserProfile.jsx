/*
1. create a reactjs component CreateUserProfile 
2. wizard like tabs
 Basic, 
Credentials 
3. Basic should have elements 
First Name
Last Name 
4. credentials 
email 
roles as select from "BA, Developer, Management"
5. the labels styles
a) no cursor
b) label and control next to each other  
c) minwidth of 100
6 Basic, Credentials tab styles
a) tab content should be centered on the screen with 70% of space
b) show selected tab highlighted with blue 
c) have prev and next options with also a d)create button on the last tab
e) add some space between the buttons
7. use bootstrap classes for all the styling

*/
import React, { useState } from 'react';
import { Tab, Tabs, Form, Button, Container, Row, Col } from 'react-bootstrap';

function CreateUserProfile() {
  const [key, setKey] = useState('basic');

  return (
    <Container className="d-flex justify-content-center">
      <div style={{ width: '70%' }}>
        <Tabs
          id="controlled-tab-example"
          activeKey={key}
          onSelect={(k) => setKey(k)}
          className="mb-3"
        >
          <Tab eventKey="basic" title="Basic">
            <Form>
              <Form.Group className="mb-3" as={Row}>
                <Form.Label column sm="2" style={{ cursor: 'none', minWidth: '100px' }}>First Name</Form.Label>
                <Col sm="10">
                  <Form.Control type="text" placeholder="Enter First Name" />
                </Col>
              </Form.Group>
              <Form.Group className="mb-3" as={Row}>
                <Form.Label column sm="2" style={{ cursor: 'none', minWidth: '100px' }}>Last Name</Form.Label>
                <Col sm="10">
                  <Form.Control type="text" placeholder="Enter Last Name" />
                </Col>
              </Form.Group>
              {key !== 'credentials' && (
                <Button variant="primary" onClick={() => setKey('credentials')} className="me-2">
                  Next
                </Button>
              )}
            </Form>
          </Tab>
          <Tab eventKey="credentials" title="Credentials">
            <Form>
              <Form.Group className="mb-3" as={Row}>
                <Form.Label column sm="2" style={{ cursor: 'none', minWidth: '100px' }}>Email</Form.Label>
                <Col sm="10">
                  <Form.Control type="email" placeholder="Enter Email" />
                </Col>
              </Form.Group>
              <Form.Group className="mb-3" as={Row}>
                <Form.Label column sm="2" style={{ cursor: 'none', minWidth: '100px' }}>Role</Form.Label>
                <Col sm="10">
                  <Form.Select>
                    <option>BA</option>
                    <option>Developer</option>
                    <option>Management</option>
                  </Form.Select>
                </Col>
              </Form.Group>
              {key !== 'basic' && (
                <Button variant="primary" onClick={() => setKey('basic')} className="me-2">
                  Prev
                </Button>
              )}&nbsp;
              <Button variant="primary" type="submit">
                Create
              </Button>
            </Form>
          </Tab>
        </Tabs>
      </div>
    </Container>
  );
}

export default CreateUserProfile;

