// components/Header.js

import React from 'react';
import logo from './logo.png'
import settings from './settings.png'
import SearchBox from './SearchBox'
const Header = () => {
  return (
    <header class="bg-primary text-white">
	
    
    
      {/* Your logo */}
	  
      <img src={logo} alt="Logo" width="60" height="60"/>
	      <h2>Data Marketplace</h2>
		  <SearchBox/>
		<img src={settings} alt="Logo" width="50" height="50"/>
      
    </header>
  );
};

export default Header;
