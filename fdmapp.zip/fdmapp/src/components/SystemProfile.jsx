import React, { useState } from 'react';

const SystemProfile = () => {
  const [appName, setAppName] = useState('');
  const [profileName, setProfileName] = useState('');
  const [appOwner, setAppOwner] = useState('');
  

  const containerStyle = {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '10px',
  };

	const labelStyle = {
    padding: '5px',
    width: '100%',
  };
  const inputStyle = {
    padding: '5px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    marginRight: '10px',
    width: '100%',
  };
    const requiredStyle = {
    color: 'red',
    marginLeft: '5px',
  };
  
   const formStyle = {
    maxWidth: '100%',
    padding: '20px',
    boxSizing: 'border-box',
    /* Add other styling as needed */
  };
  
  
  const callAzureFunction = async () => {
  try {
    const response = await fetch('https://fdmapi.azure.windows.net', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        appName,
        profileName,
        appOwner,
      }),
    });
    const data = await response.json();
    console.log('Azure function response:', data);
  } catch (error) {
    console.error('Error calling Azure function:', error);
  }
};

  const handleSubmit = () => {
    // Handle form submission (e.g., call Azure function)
    const formData = {
      appName,
      profileName,
      appOwner,
    };
    console.log('Form data submitted:', formData);
    // Call Azure function here
	callAzureFunction();
  };

  return (
       <div style={formStyle} >
      <h1>Create a System Profile</h1>
       <div style={containerStyle}>
        <label htmlFor="appName" style={labelStyle}> App Name<span style={requiredStyle}>*</span>:</label>
        <input
          type="text"
          id="appName"
          value={appName}
          onChange={(e) => setAppName(e.target.value)}
		  style={inputStyle}
        />
      </div>
       <div style={containerStyle}>
        <label htmlFor="profileName" style={labelStyle}>Map ID<span style={requiredStyle}>*</span>:</label>
        <input
          type="text"
          id="profileName"
          value={profileName}
          onChange={(e) => setProfileName(e.target.value)}
		  style={inputStyle}
        />
      </div>
       <div style={containerStyle} >
        <label htmlFor="appOwner" style={labelStyle}>App Owner<span style={requiredStyle}>*</span>:</label>
        <input
          type="text"
          id="appOwner"
          value={appOwner}
          onChange={(e) => setAppOwner(e.target.value)}
		  style={inputStyle}
        />
      </div>
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
  
  

};


export default SystemProfile;
