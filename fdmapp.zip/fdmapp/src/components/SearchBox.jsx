// SearchBar.js
/*
create reactjs MainPanelContainer routes display home party customer based on selected option SearchContext context api
*/
import React, { createContext, useContext, useState } from 'react';
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css'; // Import the default styles
import { SearchContext } from './Contexts';



const SearchBox = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showOptions, setShowOptions] = useState(false); // New state for showing/hiding options
const { selectedPage, setSelectedPage } = useContext(SearchContext);
  // Mock data for autocomplete options
  const options = ['Home', 'Create Application','Create User Profile','Create System Profile','Create Security Role','Create Security Group','Manage Applications','Manage Security Groups','Manage Security Roles','Maintain Security Assignments','Maintain Data Security Roles'];

  const handleInputChange = (event) => {
	
    const value = event.target.value;
	
	if(value.length<=3)
		setShowOptions(false);
	else
		setShowOptions(true); // Show options while typing
    
	
	setSearchTerm(value);
	
	setSelectedPage(value);
	
  };

  const handleSelect = (option) => {
    setShowOptions(false); // Hide options after selection
	setSelectedPage(option);
    setSearchTerm("");
  };

  return (
  
    <Popup trigger={<input
        type="text"
        placeholder="Search..."
        value={searchTerm}
        onChange={handleInputChange} 
      />} position="bottom left" style={{width:'300'}} zIndex="9999">
    <div>
	{ showOptions && ( // Show options only when showOptions is true
		<ul style={{width:'100%'}}>
          {options
            .filter((option) =>
              option.toLowerCase().includes(searchTerm.toLowerCase())
            )
            .map((option) => (
              <li key={option} onClick={() => handleSelect(option)} style={{fontcolor:'black'}}>
                {option}
              </li>
            ))}
        </ul>
      )}
		
	</div>
  </Popup>
  );
};

export default SearchBox;

// HomeComponent.js and CustomerComponent.js remain the same
