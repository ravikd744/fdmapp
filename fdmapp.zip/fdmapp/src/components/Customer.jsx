// components/Customer.js

import React from 'react';

const Customer = () => {
  // Handle form submission and API call
  const handleSubmit = (e) => {
    e.preventDefault();
    // Call postCustomer API
  };

  return (
    <div className="customer">
      <form onSubmit={handleSubmit}>
        <label>Customer Name:</label>
        <input type="text" />

        <label>Customer Address:</label>
        <input type="text" />

        <label>Customer Province:</label>
        <select>
          <option value="ON">ON</option>
          <option value="BC">BC</option>
          <option value="QU">QU</option>
        </select>

        <button type="submit">Submit</button>
      </form>
    </div>
  );
};

export default Customer;
