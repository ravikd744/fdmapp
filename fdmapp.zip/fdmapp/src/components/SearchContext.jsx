// SearchContext.js
import { createContext } from 'react';
const SearchContext = createContext('search');
