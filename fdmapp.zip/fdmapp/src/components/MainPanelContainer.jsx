// MainPanelContainer.js
import { lazy, Suspense } from 'react';
import React, { createContext, useContext, useState } from 'react';
import { SearchContext } from './Contexts';


import Home from './Home';
import CreateUserProfile from './CreateUserProfile';
import Application from './Application';
import SystemProfile from './SystemProfile';

const MainPanelContainer = () => {
const __dirname = import.meta.dirname;
	// Define a function that takes the component name as a parameter
	const { selectedPage, setSelectedPage } = useContext(SearchContext);
const loadComponent = (componentName) => {
  // Construct the module path based on the component name
  const componentPath = './'+selectedPage;

  // Dynamically import the component using React.lazy()
  const lazyComponent=lazy(() => import(componentPath));
  return(<div>hghh
  <lazyComponent/>
  </div>);
};
	if(selectedPage==='Create User Profile')
		return <div><CreateUserProfile/></div>
	if(selectedPage==='Create Application')
		return <div><Application/></div>
	if(selectedPage==='Create System Profile')
		return <div><SystemProfile/></div>
	else
		return <div><Home/></div>
	
};

export default MainPanelContainer;
