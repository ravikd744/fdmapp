// Contexts.js
import { createContext } from 'react';

export const SearchContext = createContext('Home');
