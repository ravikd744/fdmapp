import React, { useState } from 'react';

const Application = () => {
  const [appName, setAppName] = useState('');
  const [mapId, setMapId] = useState('');
  const [lob, setLob] = useState('');
  const [appOwner, setAppOwner] = useState('');
  const [billingManager, setBillingManager] = useState('');
  const [costCenter, setCostCenter] = useState('');

  const containerStyle = {
    display: 'flex',
    alignItems: 'center',
    marginBottom: '10px',
  };

	const labelStyle = {
    padding: '5px',
    width: '100%',
  };
  const inputStyle = {
    padding: '5px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    marginRight: '10px',
    width: '100%',
  };
    const requiredStyle = {
    color: 'red',
    marginLeft: '5px',
  };
  
   const formStyle = {
    maxWidth: '100%',
    padding: '20px',
    boxSizing: 'border-box',
    /* Add other styling as needed */
  };
  
  
  const callAzureFunction = async () => {
  try {
    const response = await fetch('https://fdmapi.azure.windows.net', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        appName,
        mapId,
        lob,
        appOwner,
        billingManager,
        costCenter,
      }),
    });
    const data = await response.json();
    console.log('Azure function response:', data);
  } catch (error) {
    console.error('Error calling Azure function:', error);
  }
};

  const handleSubmit = () => {
    // Handle form submission (e.g., call Azure function)
    const formData = {
      appName,
      mapId,
      lob,
      appOwner,
      billingManager,
      costCenter,
    };
    console.log('Form data submitted:', formData);
    // Call Azure function here
	callAzureFunction();
  };

  return (
       <div style={formStyle} >
      <h1>Create an Application</h1>
       <div style={containerStyle}>
        <label htmlFor="appName" style={labelStyle}> App Name<span style={requiredStyle}>*</span>:</label>
        <input
          type="text"
          id="appName"
          value={appName}
          onChange={(e) => setAppName(e.target.value)}
		  style={inputStyle}
        />
      </div>
       <div style={containerStyle}>
        <label htmlFor="mapId" style={labelStyle}>Map ID<span style={requiredStyle}>*</span>:</label>
        <input
          type="text"
          id="mapId"
          value={mapId}
          onChange={(e) => setMapId(e.target.value)}
		  style={inputStyle}
        />
      </div>
       <div style={containerStyle}>
        <label htmlFor="lob" style={labelStyle}>Line of Business (LOB)<span style={requiredStyle}>*</span>:</label>
        <select
          id="lob"
          value={lob}
          onChange={(e) => setLob(e.target.value)}
		  style={inputStyle}
        >
          <option value="">Select LOB</option>
          <option value="PBB">PBB</option>
          <option value="Commercial">Commercial</option>
          <option value="Wealth">Wealth</option>
          <option value="Capital Markets">Capital Markets</option>
          <option value="Enterprise">Enterprise</option>
        </select>
      </div>
       <div style={containerStyle} >
        <label htmlFor="appOwner" style={labelStyle}>App Owner<span style={requiredStyle}>*</span>:</label>
        <input
          type="text"
          id="appOwner"
          value={appOwner}
          onChange={(e) => setAppOwner(e.target.value)}
		  style={inputStyle}
        />
      </div>
      <div style={containerStyle} >
        <label htmlFor="billingManager" style={labelStyle}>Billing Manager<span style={requiredStyle}>*</span>:</label>
        <input
          type="text"
          id="billingManager"
          value={billingManager}
          onChange={(e) => setBillingManager(e.target.value)}
		  style={inputStyle}
        />
      </div>
      <div style={containerStyle} >
        <label htmlFor="costCenter" style={labelStyle}>Cost Center<span style={requiredStyle}>*</span>:</label>
        <input
          type="text"
          id="costCenter"
          value={costCenter}
          onChange={(e) => setCostCenter(e.target.value)}
		  style={inputStyle}
        />
      </div>
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
  
  

};


export default Application;

/*SQL DDL
CREATE TABLE FDM.Application (
  id INT PRIMARY KEY,
  appName VARCHAR(255) NOT NULL,
  mapId VARCHAR(255) NOT NULL,
  lob VARCHAR(50) NOT NULL,
  appOwner VARCHAR(255) NOT NULL,
  billingManager VARCHAR(255) NOT NULL,
  costCenter VARCHAR(50) NOT NULL,
  -- Add other columns for bi-temporal model
  validFrom DATETIME,
  validTo DATETIME,
  systemStart DATETIME2 GENERATED ALWAYS AS ROW START,
  systemEnd DATETIME2 GENERATED ALWAYS AS ROW END,
  PERIOD FOR SYSTEM_TIME (systemStart, systemEnd)
);

*/

/*

Azure function code

// Azure Function (Node.js)
module.exports = async function (context, req) {
  try {
    const data = req.body; // JSON data from the client
    // Process data (e.g., insert into SQL database)
    // ...
    context.res = {
      status: 200,
      body: 'Data processed successfully',
    };
  } catch (error) {
    context.res = {
      status: 500,
      body: 'Error processing data',
    };
  }
};

*/